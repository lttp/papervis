*Electrical comsumption in France in 2014 (with weekends and hollidays highlighted)*

[https://github.com/nicgirault/circosJS](https://github.com/nicgirault/circosJS)
