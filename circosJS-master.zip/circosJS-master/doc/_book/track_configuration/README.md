# Track configuration

* innerRadius
* outerRadius
* min
* max
* logScale

|  | Scatter | Line | Heatmap | Histogram | Stack | Chords |
| -- | -- | -- | -- | -- | -- | -- |
| innerRadius | yes | yes | yes | yes | yes | yes |
| outerRadius | yes | yes | yes | yes | yes | yes |
| min | yes | yes | yes | yes | yes | yes |
| max | yes | yes | yes | yes | yes | yes |
| logScale | yes | yes | yes | yes | yes | yes |
| direction | yes | yes | yes | yes | yes | yes |
| usePalette | yes | yes | yes | yes | yes | yes |
| colorPalette | yes | yes | yes | yes | yes | yes |
| colorPaletteSize | yes | yes | yes | yes | yes | yes |
| color | yes | yes | yes | yes | yes | yes |
| opacity | yes | yes | yes | yes | yes | yes |
| fill | yes | yes | yes | yes | yes | yes |
| fill_color | yes | yes | yes | yes | yes | yes |
| thickness | yes | yes | yes | yes | yes | yes |
| max_gap | yes | yes | yes | yes | yes | yes |
| interpolation | yes | yes | yes | yes | yes | yes |
| fill | yes | yes | yes | yes | yes | yes |
| fill | yes | yes | yes | yes | yes | yes |
