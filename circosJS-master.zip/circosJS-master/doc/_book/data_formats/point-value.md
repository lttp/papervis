# Point-Value

This data format is shared with scatter and lines

```javascript
var data = [
    {
        parent: 'january',
        data: [
            {position: 1, value: 2},
            {position: 20, value: 13},
            {position: 7, value: -3}
        ]
    },
    {
        parent: 'february',
        data: [
            {position: 5, value: 1},
            {position: 20, value: 4}
        ]
    },
    ...
]
```
