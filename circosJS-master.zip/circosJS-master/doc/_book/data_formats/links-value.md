# Links-Value

This data format is used by chord tracks:

```javascript
chords_data = [
    {
        source: {id: 'january', start: 1, end: 12},
        target: {id: 'april', start: 18, end: 20},
        value: 2
    },
    {
        source: {id: 'february', start: 20, end: 28},
        target: {id: 'december', start: 1, end: 13},
        value: 1
    }
];
```
