links = [
  {
    source: {id: 'january', start: 1, end: 10},
    target: {id: 'february', start: 20, end: 25},
    value: 0
  },
  {
    source: {id: 'march', start: 1, end: 10},
    target: {id: 'december', start: 20, end: 25},
    value: 1
  },
  {
    source: {id: 'march', start: 8, end: 10},
    target: {id: 'august', start: 7, end: 25},
    value: 2
  },
  {
    source: {id: 'april', start: 13, end: 15},
    target: {id: 'november', start: 10, end: 25},
    value: 3
  }
];
