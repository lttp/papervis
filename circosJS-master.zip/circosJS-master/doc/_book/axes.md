# Axes

In histogram, stack, line and scatter tracks, you can display axes.

```javascript
axes: {
  display: true,
  minor: {
    spacing: 5,
    spacingType: 'pixel',
    color: '#d3d3d3',
    thickness: 2
  },
  major: {
    spacing: 5,
    color: '#000000',
    thickness: 2
  }
}
```

TODO
